# Alumni Website Django
 Simple Alumni site with CRUD operations and Blog
